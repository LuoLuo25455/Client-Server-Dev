from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    def __init__(self, USER, PASS, HOST, PORT, DB, COL):

        # Root variables, will NOT be used 
        #USER = 'root'
        #PASS = '7fE4AfspKS'
        #HOST = 'nv-desktop-services.apporto.com'
        #PORT = 31275
        #DB = 'aac'
        #COL = 'animals'

        # Try making the connection, return exception if failed
        try:
            self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
            self.database = self.client['%s' % (DB)]
            self.collection = self.database['%s' % (COL)]
        except Exception as e:
            print(f"Connection error: {e}")

    # C - Create
    def create(self, data):
        # if the input 'data' is not null, then insert
        if data is not None:
            query = self.database.animals.insert_one(data)
            # return true if successful insert, else false
            if query.inserted_id:
                return True
            else:
                return False
        # else return exception
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            return False

    # R - Read
    def read(self, data):
        # if the input 'data' is not null, then read
        if data is not None:
            # read could return multiple results, so use list(find.(data))
            return list(self.database.animals.find(data))
        # else return exception and return an empty list
        else:
            raise Exception("Nothing to read, because data parameter is empty")
            return []

    # U - Update
    def update(self, data, updated_data):
        # if the input 'data' is not null, then update
        if data is not None:
            # update all entries
            query = self.database.animals.update_many(data, {"$set": updated_data})
            # return number of entries being updated
            return query.modified_count
        #else return exception and return 0
        else:
            raise Exception("Nothing to update, because data parameter is empty")
            return 0

    # D - Delete
    def delete(self, data):
        # if the input 'data' is not null, then delete
        if data is not None:
            #delete all entries
            query = self.database.animals.delete_many(data)
            # return number of entries being deleted
            return query.deleted_count
        # else return exception and return 0
        else:
            raise Exception("Nothing to delete, because data parameter is empty")
            return 0

    # close connection after operation is finished
    def close_connection(self):
        self.client.close()


